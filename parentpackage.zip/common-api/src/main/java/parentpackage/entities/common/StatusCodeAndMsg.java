package parentpackage.entities.common;

/**
 * @author zepeng.lin
 * @date 2020/9/25
 * 存储静态resultCode和resultMsg的类
 * 皆运用public static修饰
 */
public class StatusCodeAndMsg {

}
