package parentpackage.entities;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

/**
 * @author zepeng.lin
 * @date 2020/9/25
 * 服务详情表
 * 服务详情信息还待确认，所以此表暂时无字段
 */
@AllArgsConstructor
@NoArgsConstructor
public class ServiceDetail {

    /**
     * 服务ID号
     */
    private String serviceId;
}
